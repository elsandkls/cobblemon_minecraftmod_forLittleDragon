"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var cobbled_debug_client_exports = {};
__export(cobbled_debug_client_exports, {
  startClient: () => startClient
});
module.exports = __toCommonJS(cobbled_debug_client_exports);
var Net = __toESM(require("net"));
var readline = __toESM(require("readline"));
function startClient(port) {
  const client = new Net.Socket();
  client.on("data", (data) => {
    console.log(data.toString());
  });
  client.on("close", (data) => {
    console.log("Connection closed.");
    client.destroy();
  });
  client.connect(port, "localhost", () => {
    console.log("Connected");
  });
  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
  });
  rl.on("line", (line) => {
    client.write(line);
  });
}
//# sourceMappingURL=cobbled-debug-client.js.map
